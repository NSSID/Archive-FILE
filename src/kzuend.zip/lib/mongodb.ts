import mongoose from 'mongoose';

// Use a direct connection string without query parameters
const MONGODB_URI = 'mongodb+srv://radityapbg5:xK0db5mbG14Hepbr@clusterfree.p14m90y.mongodb.net/senkodb';

// Global interface for mongoose connection
interface MongooseConnection {
  conn: typeof mongoose | null;
  promise: Promise<typeof mongoose> | null;
}

// Add mongoose to global type
declare global {
  var mongoose: MongooseConnection;
}

// Initialize global mongoose object
if (!global.mongoose) {
  global.mongoose = {
    conn: null,
    promise: null,
  };
}

export async function connectToDatabase() {
  try {
    // If we already have a connection, return it
    if (global.mongoose.conn) {
      return global.mongoose.conn;
    }

    // If a connection is in progress, wait for it
    if (global.mongoose.promise) {
      return await global.mongoose.promise;
    }

    // Configure mongoose (disable strict query for flexibility)
    mongoose.set('strictQuery', false);

    // Create a new connection
    global.mongoose.promise = mongoose.connect(MONGODB_URI);
    global.mongoose.conn = await global.mongoose.promise;
    
    console.log('MongoDB connected successfully');
    return global.mongoose.conn;
  } catch (error) {
    console.error('MongoDB connection error:', error);
    global.mongoose.promise = null;
    throw error;
  }
}

export default connectToDatabase; 