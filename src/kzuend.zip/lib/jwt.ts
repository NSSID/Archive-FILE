// @ts-ignore
import jwt from 'jsonwebtoken';
import { IUser } from '../models/User';

// Secret key for signing tokens
const JWT_SECRET = process.env.JWT_SECRET || 'senko-api-jwt-secret-key-2024';
// Token expiration (1 day)
const JWT_EXPIRES_IN = '1d';

export interface JwtPayload {
  id: string;
  username: string;
  email: string;
  role: string;
}

/**
 * Generate a JWT token for a user
 */
export function generateToken(user: any): string {
  const payload: JwtPayload = {
    id: user._id.toString(),
    username: user.username,
    email: user.email,
    role: user.role,
  };

  return jwt.sign(payload, JWT_SECRET, {
    expiresIn: JWT_EXPIRES_IN,
  });
}

/**
 * Verify a JWT token
 */
export function verifyToken(token: string): JwtPayload | null {
  try {
    return jwt.verify(token, JWT_SECRET) as JwtPayload;
  } catch (error) {
    return null;
  }
}

/**
 * Get user from token in request
 */
export function getUserFromToken(request: Request): JwtPayload | null {
  try {
    const authHeader = request.headers.get('authorization');
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return null;
    }

    const token = authHeader.split(' ')[1];
    return verifyToken(token);
  } catch (error) {
    return null;
  }
} 