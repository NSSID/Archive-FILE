import type { NextRequest } from "next/server"
import fs from "fs"
import path from "path"

interface ApiKey {
  id: string
  key: string
  name: string
  userId: string
  permissions: string[]
  rateLimit: {
    requests: number
    window: string
  }
  usage: {
    totalRequests: number
    lastUsed: string | null
  }
  status: "active" | "inactive" | "suspended"
  createdAt: string
  expiresAt: string | null
}

interface ApiKeyDatabase {
  apiKeys: ApiKey[]
}

// Load API keys from database
function loadApiKeys(): ApiKeyDatabase {
  try {
    const dbPath = path.join(process.cwd(), "database", "users", "apikey.json")
    const data = fs.readFileSync(dbPath, "utf8")
    return JSON.parse(data)
  } catch (error) {
    console.error("Error loading API keys:", error)
    return { apiKeys: [] }
  }
}

// Save API keys to database
function saveApiKeys(data: ApiKeyDatabase): void {
  try {
    const dbPath = path.join(process.cwd(), "database", "users", "apikey.json")
    const dir = path.dirname(dbPath)

    // Ensure directory exists
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true })
    }

    fs.writeFileSync(dbPath, JSON.stringify(data, null, 2))
  } catch (error) {
    console.error("Error saving API keys:", error)
  }
}

// Validate API key
export function validateApiKey(apiKey: string): { valid: boolean; keyData?: ApiKey; error?: string } {
  if (!apiKey) {
    return { valid: false, error: "API key is required" }
  }

  const db = loadApiKeys()
  const keyData = db.apiKeys.find((key) => key.key === apiKey)

  if (!keyData) {
    return { valid: false, error: "Invalid API key" }
  }

  if (keyData.status !== "active") {
    return { valid: false, error: "API key is not active" }
  }

  // Check expiration
  if (keyData.expiresAt && new Date(keyData.expiresAt) < new Date()) {
    return { valid: false, error: "API key has expired" }
  }

  return { valid: true, keyData }
}

// Update API key usage
export function updateApiKeyUsage(apiKey: string): void {
  try {
    const db = loadApiKeys()
    const keyIndex = db.apiKeys.findIndex((key) => key.key === apiKey)

    if (keyIndex !== -1) {
      db.apiKeys[keyIndex].usage.totalRequests += 1
      db.apiKeys[keyIndex].usage.lastUsed = new Date().toISOString()
      saveApiKeys(db)
    }
  } catch (error) {
    console.error("Error updating API key usage:", error)
  }
}

// Extract API key from request
export function extractApiKey(request: NextRequest): string | null {
  // Try query parameter first
  const apiKey = request.nextUrl.searchParams.get("apikey")
  if (apiKey) return apiKey

  // Try header
  const headerKey = request.headers.get("x-api-key") || request.headers.get("authorization")?.replace("Bearer ", "")
  if (headerKey) return headerKey

  return null
}

// Middleware function for API key validation
export function requireApiKey(request: NextRequest): { success: boolean; error?: string; keyData?: ApiKey } {
  const apiKey = extractApiKey(request)

  if (!apiKey) {
    return {
      success: false,
      error: "API key is required. Provide it as 'apikey' query parameter or 'X-API-Key' header.",
    }
  }

  const validation = validateApiKey(apiKey)

  if (!validation.valid) {
    return { success: false, error: validation.error }
  }

  // Update usage statistics
  updateApiKeyUsage(apiKey)

  return { success: true, keyData: validation.keyData }
}
