# Remove node_modules and lock files
rm -rf node_modules
rm -rf .next
rm pnpm-lock.yaml  # or package-lock.json if using npm

# Reinstall dependencies
pnpm install  # or npm install if you prefer npm

