"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Loader2, RefreshCw, Download, ExternalLink, ArrowLeft } from "lucide-react"
import { ThemeToggle } from "@/components/theme-toggle"
import Image from "next/image"

interface AnimeResult {
  url: string
  extension: string
  source: string
  category: string
  type: string
  character?: string
  timestamp: string
}

interface ApiResponse {
  status: boolean
  result?: AnimeResult
  message?: string
  error?: string
}

export default function AnimeTestPage() {
  const [results, setResults] = useState<{ [key: string]: ApiResponse }>({})
  const [loading, setLoading] = useState<{ [key: string]: boolean }>({})

  const animeApis = [
    { id: "waifu", name: "Waifu", endpoint: "/api/anime/waifu", description: "Random anime waifu images" },
    { id: "neko", name: "Neko", endpoint: "/api/anime/neko", description: "Random anime neko (cat girl) images" },
    { id: "shinobu", name: "Shinobu", endpoint: "/api/anime/shinobu", description: "Random Shinobu Kocho images" },
  ]

  const testApi = async (apiId: string, endpoint: string) => {
    setLoading((prev) => ({ ...prev, [apiId]: true }))

    try {
      const response = await fetch(endpoint)
      const data = await response.json()
      setResults((prev) => ({ ...prev, [apiId]: data }))
    } catch (error) {
      setResults((prev) => ({
        ...prev,
        [apiId]: {
          status: false,
          message: "Network error",
          error: error instanceof Error ? error.message : "Unknown error",
        },
      }))
    } finally {
      setLoading((prev) => ({ ...prev, [apiId]: false }))
    }
  }

  const downloadImage = async (url: string, filename: string) => {
    try {
      const response = await fetch(url)
      const blob = await response.blob()
      const downloadUrl = window.URL.createObjectURL(blob)
      const link = document.createElement("a")
      link.href = downloadUrl
      link.download = filename
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      window.URL.revokeObjectURL(downloadUrl)
    } catch (error) {
      console.error("Download failed:", error)
    }
  }

  return (
    <div className="min-h-screen bg-orange-100 dark:bg-gray-900 oled:bg-black transition-all duration-500">
      {/* Header */}
      <header className="glass dark:glass-dark oled:glass-oled border-b border-orange-200/50 dark:border-gray-700/50 oled:border-gray-900/50 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4 slide-in-left">
              <Button
                variant="outline"
                size="sm"
                onClick={() => window.history.back()}
                className="border-orange-300 dark:border-gray-600 oled:border-gray-800 text-orange-700 dark:text-gray-100 oled:text-gray-100 hover:bg-orange-50 dark:hover:bg-gray-800 oled:hover:bg-gray-900 hover-lift"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Kembali
              </Button>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-orange-600 to-orange-800 dark:from-gray-100 dark:to-gray-300 oled:from-gray-200 oled:to-gray-400 bg-clip-text text-transparent">
                🎌 Anime API Test
              </h1>
            </div>
            <ThemeToggle />
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8 text-center slide-in-up">
          <p className="text-lg text-orange-600 dark:text-gray-200 oled:text-gray-200">
            Test semua endpoint API anime yang tersedia
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
          {animeApis.map((api, index) => (
            <Card
              key={api.id}
              className={`glass dark:glass-dark oled:glass-oled border-orange-200/50 dark:border-gray-700/50 oled:border-gray-900/50 hover-lift slide-in-up delay-${
                (index + 1) * 100
              }`}
            >
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-orange-800 dark:text-white oled:text-white">{api.name}</CardTitle>
                  <Badge
                    variant="outline"
                    className="border-orange-300 dark:border-gray-600 oled:border-gray-800 text-orange-700 dark:text-gray-100 oled:text-gray-100 bg-orange-50/50 dark:bg-gray-800/50 oled:bg-black/50"
                  >
                    anime
                  </Badge>
                </div>
                <CardDescription className="text-orange-600 dark:text-gray-200 oled:text-gray-200">
                  {api.description}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button
                  onClick={() => testApi(api.id, api.endpoint)}
                  disabled={loading[api.id]}
                  className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white transition-all duration-300 hover:scale-105 hover:shadow-lg"
                >
                  {loading[api.id] ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Loading...
                    </>
                  ) : (
                    <>
                      <RefreshCw className="mr-2 h-4 w-4" />
                      Test API
                    </>
                  )}
                </Button>

                {results[api.id] && (
                  <div className="space-y-3 slide-in-up">
                    {results[api.id].status ? (
                      <div className="space-y-3">
                        <div className="relative aspect-square rounded-lg overflow-hidden bg-gradient-to-br from-orange-100 to-orange-200 dark:from-gray-800 dark:to-gray-700 oled:from-black oled:to-gray-900 hover-lift">
                          <Image
                            src={results[api.id].result!.url || "/placeholder.svg"}
                            alt={`${api.name} image`}
                            fill
                            className="object-cover transition-transform duration-300 hover:scale-105"
                            onError={(e) => {
                              const target = e.target as HTMLImageElement
                              target.src = "/placeholder.svg?height=300&width=300"
                            }}
                          />
                        </div>

                        <div className="text-xs text-orange-600 dark:text-gray-200 oled:text-gray-200 space-y-1 bg-orange-50/50 dark:bg-gray-800/50 oled:bg-black/50 p-3 rounded-lg">
                          <p>
                            <strong>Type:</strong> {results[api.id].result!.type}
                          </p>
                          <p>
                            <strong>Extension:</strong> {results[api.id].result!.extension}
                          </p>
                          <p>
                            <strong>Source:</strong> {results[api.id].result!.source}
                          </p>
                          {results[api.id].result!.character && (
                            <p>
                              <strong>Character:</strong> {results[api.id].result!.character}
                            </p>
                          )}
                        </div>

                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() =>
                              downloadImage(
                                results[api.id].result!.url,
                                `${api.id}-${Date.now()}.${results[api.id].result!.extension}`,
                              )
                            }
                            className="flex-1 border-orange-300 dark:border-gray-600 oled:border-gray-800 text-orange-700 dark:text-gray-100 oled:text-gray-100 hover:bg-orange-50 dark:hover:bg-gray-800 oled:hover:bg-gray-900 hover-lift"
                          >
                            <Download className="mr-1 h-3 w-3" />
                            Download
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => window.open(results[api.id].result!.url, "_blank")}
                            className="flex-1 border-orange-300 dark:border-gray-600 oled:border-gray-800 text-orange-700 dark:text-gray-100 oled:text-gray-100 hover:bg-orange-50 dark:hover:bg-gray-800 oled:hover:bg-gray-900 hover-lift"
                          >
                            <ExternalLink className="mr-1 h-3 w-3" />
                            Open
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <div className="p-3 bg-gradient-to-r from-red-50 to-red-100 dark:from-red-900/20 dark:to-red-800/20 oled:from-red-900/10 oled:to-red-800/10 border border-red-200 dark:border-red-800/50 oled:border-red-900/50 rounded-lg slide-in-up">
                        <p className="text-red-700 dark:text-red-300 oled:text-red-200 text-sm font-medium">Error:</p>
                        <p className="text-red-600 dark:text-red-200 oled:text-red-100 text-sm">
                          {results[api.id].message}
                        </p>
                        {results[api.id].error && (
                          <p className="text-red-500 dark:text-red-300 oled:text-red-200 text-xs mt-1">
                            {results[api.id].error}
                          </p>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}
