"use client"

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Button } from '@/components/ui/button'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { AlertCircle, User, Mail, Calendar, ArrowLeft } from 'lucide-react'

interface UserData {
  id: string
  username: string
  displayName?: string
  email: string
  avatar?: string
  role: string
  createdAt?: string
}

export default function ProfilePage() {
  const router = useRouter()
  const [user, setUser] = useState<UserData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    // Check if user is logged in from localStorage
    const checkAuth = () => {
      const token = localStorage.getItem('token')
      const storedUser = localStorage.getItem('user')
      
      if (!token || !storedUser) {
        router.push('/auth/login')
        return
      }
      
      try {
        setUser(JSON.parse(storedUser))
        
        // Fetch latest user data from API
        fetchUserProfile(token)
      } catch (error) {
        console.error('Error parsing user data:', error)
        router.push('/auth/login')
      }
    }
    
    checkAuth()
  }, [router])
  
  const fetchUserProfile = async (token: string) => {
    try {
      const response = await fetch('/api/auth/me', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })
      
      if (!response.ok) {
        if (response.status === 401) {
          // Token expired or invalid
          localStorage.removeItem('token')
          localStorage.removeItem('user')
          router.push('/auth/login')
          return
        }
        
        throw new Error('Failed to fetch profile')
      }
      
      const data = await response.json()
      
      if (data.success && data.user) {
        setUser(data.user)
        // Update stored user data
        localStorage.setItem('user', JSON.stringify(data.user))
      }
    } catch (error: any) {
      setError(error.message || 'Failed to load profile')
    } finally {
      setLoading(false)
    }
  }
  
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(part => part[0])
      .join('')
      .toUpperCase()
      .substring(0, 2)
  }
  
  const formatDate = (dateString?: string) => {
    if (!dateString) return 'N/A'
    return new Date(dateString).toLocaleDateString('id-ID', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    })
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-orange-100 dark:bg-gray-900 oled:bg-black flex items-center justify-center">
        <div className="relative">
          <div className="animate-spin rounded-full h-32 w-32 border-t-4 border-b-4 border-orange-500 dark:border-gray-400 oled:border-gray-300"></div>
          <div className="absolute inset-0 animate-ping rounded-full h-32 w-32 border-4 border-orange-300 dark:border-gray-600 oled:border-gray-500 opacity-20"></div>
        </div>
      </div>
    )
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-orange-100 dark:bg-gray-900 oled:bg-black flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>Profile Not Found</CardTitle>
            <CardDescription>You need to login to view your profile</CardDescription>
          </CardHeader>
          <CardFooter>
            <Button onClick={() => router.push('/auth/login')}>Go to Login</Button>
          </CardFooter>
        </Card>
      </div>
    )
  }

  const displayName = user.displayName || user.username
  const initials = getInitials(displayName)

  return (
    <div className="min-h-screen bg-orange-100 dark:bg-gray-900 oled:bg-black p-4">
      <div className="container mx-auto max-w-4xl">
        <Button 
          variant="ghost" 
          onClick={() => router.push('/')}
          className="mb-4"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Dashboard
        </Button>
        
        {error && (
          <Alert className="mb-4 bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800">
            <AlertCircle className="h-4 w-4 text-red-600 dark:text-red-400" />
            <AlertDescription className="text-red-600 dark:text-red-400">{error}</AlertDescription>
          </Alert>
        )}
        
        <Card className="glass dark:glass-dark oled:glass-oled border-orange-200/50 dark:border-gray-700/50 oled:border-gray-900/50">
          <CardHeader className="flex flex-col items-center border-b border-orange-100 dark:border-gray-800 oled:border-gray-900">
            <div className="w-24 h-24 mb-4">
              <Avatar className="w-full h-full">
                <AvatarImage src={user.avatar || '/placeholder-user.jpg'} alt={displayName} />
                <AvatarFallback className="text-2xl">{initials}</AvatarFallback>
              </Avatar>
            </div>
            <CardTitle className="text-2xl font-bold bg-gradient-to-r from-orange-600 to-orange-800 dark:from-gray-100 dark:to-gray-300 oled:from-gray-200 oled:to-gray-400 bg-clip-text text-transparent">
              {displayName}
            </CardTitle>
            <CardDescription className="text-orange-600 dark:text-gray-400 oled:text-gray-400">
              {user.role === 'admin' ? 'Administrator' : 'User'}
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="space-y-4">
              <div className="flex items-center space-x-4">
                <User className="h-5 w-5 text-orange-500 dark:text-gray-400 oled:text-gray-400" />
                <div>
                  <p className="text-sm font-medium text-gray-500 dark:text-gray-400 oled:text-gray-400">Username</p>
                  <p className="text-gray-900 dark:text-gray-100 oled:text-white">{user.username}</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-4">
                <Mail className="h-5 w-5 text-orange-500 dark:text-gray-400 oled:text-gray-400" />
                <div>
                  <p className="text-sm font-medium text-gray-500 dark:text-gray-400 oled:text-gray-400">Email</p>
                  <p className="text-gray-900 dark:text-gray-100 oled:text-white">{user.email}</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-4">
                <Calendar className="h-5 w-5 text-orange-500 dark:text-gray-400 oled:text-gray-400" />
                <div>
                  <p className="text-sm font-medium text-gray-500 dark:text-gray-400 oled:text-gray-400">Member Since</p>
                  <p className="text-gray-900 dark:text-gray-100 oled:text-white">{formatDate(user.createdAt)}</p>
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-center border-t border-orange-100 dark:border-gray-800 oled:border-gray-900 pt-4">
            <Button 
              variant="outline" 
              onClick={() => router.push('/settings')}
              className="border-orange-300 dark:border-gray-600 oled:border-gray-800 text-orange-700 dark:text-gray-100 oled:text-gray-100 hover:bg-orange-50 dark:hover:bg-gray-800 oled:hover:bg-gray-900 hover-lift"
            >
              Edit Profile
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
} 