"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Github, Server, Clock, Zap, AlertCircle, Sparkles, TestTube } from "lucide-react"
import { ThemeToggle } from "@/components/theme-toggle"
import { AnimatedCounter } from "@/components/animated-counter"
import { StatusIndicator } from "@/components/status-indicator"
import { ApiTesterModal } from "@/components/api-tester-modal"
import { AuthNav } from "@/components/auth-nav"

interface ApiStatus {
  id: string
  name: string
  category: string
  endpoint: string
  methods: string[]
  responseType: string
  description: string
  status: "online" | "offline" | "error" | "maintenance"
  responseTime: number
  lastChecked: string
}

interface ServerStats {
  uptime: number
  totalRequests: number
  errorRate: number
  avgResponseTime: number
}

interface Notification {
  id: string
  type: "info" | "warning" | "error"
  title: string
  message: string
  timestamp: string
  active: boolean
}

export default function Dashboard() {
  const [greeting, setGreeting] = useState("")
  const [apiStatuses, setApiStatuses] = useState<ApiStatus[]>([])
  const [serverStats, setServerStats] = useState<ServerStats | null>(null)
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [settings, setSettings] = useState<any>(null)
  const [currentTime, setCurrentTime] = useState(new Date())
  const [mounted, setMounted] = useState(false)
  const [selectedApi, setSelectedApi] = useState<ApiStatus | null>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  // Generate greeting based on time
  useEffect(() => {
    const hour = new Date().getHours()
    if (hour < 12) {
      setGreeting("Ohayou gozaimasu! ☀️")
    } else if (hour < 18) {
      setGreeting("Konnichiwa! 🌤️")
    } else {
      setGreeting("Konbanwa! 🌙")
    }
  }, [])

  // Load settings and notifications
  useEffect(() => {
    const loadData = async () => {
      try {
        const [settingsRes, notificationsRes] = await Promise.all([
          fetch("/settings.json"),
          fetch("/notifications.json"),
        ])

        const settingsData = await settingsRes.json()
        const notificationsData = await notificationsRes.json()

        setSettings(settingsData)
        setApiStatuses(settingsData.apis)
        setNotifications(notificationsData.notifications.filter((n: Notification) => n.active))
      } catch (error) {
        console.error("Error loading data:", error)
      }
    }

    loadData()
  }, [])

  // Update server stats and time
  useEffect(() => {
    const fetchServerStats = async () => {
      try {
        const response = await fetch("/api/system/stats?apikey=senko_api_2024_demo_key_12345", {
          headers: {
            "X-API-Key": "senko_api_2024_demo_key_12345"
          }
        })
        if (response.ok) {
          const result = await response.json()
          if (result.status && result.data) {
            setServerStats(result.data)
          }
        }
      } catch (error) {
        console.error("Error fetching server stats:", error)
      }
    }

    // Initial fetch
    fetchServerStats()

    // Set up intervals
    const statsInterval = setInterval(fetchServerStats, 30000)
    const timeInterval = setInterval(() => setCurrentTime(new Date()), 1000)

    return () => {
      clearInterval(statsInterval)
      clearInterval(timeInterval)
    }
  }, [])

  const formatUptime = (seconds: number) => {
    const days = Math.floor(seconds / 86400)
    const hours = Math.floor((seconds % 86400) / 3600)
    const minutes = Math.floor((seconds % 3600) / 60)
    return `${days}d ${hours}h ${minutes}m`
  }

  const handleApiTest = (api: ApiStatus) => {
    setSelectedApi(api)
    setIsModalOpen(true)
  }

  if (!mounted || !settings) {
    return (
      <div className="min-h-screen bg-orange-100 dark:bg-gray-900 oled:bg-black flex items-center justify-center">
        <div className="relative">
          <div className="animate-spin rounded-full h-32 w-32 border-t-4 border-b-4 border-orange-500 dark:border-gray-400 oled:border-gray-300"></div>
          <div className="absolute inset-0 animate-ping rounded-full h-32 w-32 border-4 border-orange-300 dark:border-gray-600 oled:border-gray-500 opacity-20"></div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-orange-100 dark:bg-gray-900 oled:bg-black transition-all duration-500">
      {/* Header */}
      <header className="glass dark:glass-dark oled:glass-oled border-b border-orange-200/50 dark:border-gray-700/50 oled:border-gray-900/50 sticky top-0 z-50 transition-all duration-300">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4 slide-in-left">
              <div className="w-12 h-12 bg-gradient-to-br from-orange-400 to-orange-600 dark:from-gray-500 dark:to-gray-700 oled:from-gray-400 oled:to-gray-600 rounded-full flex items-center justify-center float-animation pulse-glow">
                <Server className="h-7 w-7 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-orange-600 to-orange-800 dark:from-gray-100 dark:to-gray-300 oled:from-gray-200 oled:to-gray-400 bg-clip-text text-transparent">
                  {settings.siteName}
                </h1>
                <p className="text-sm text-orange-600 dark:text-gray-300 oled:text-gray-300">v{settings.version}</p>
              </div>
            </div>
            <div className="flex items-center space-x-4 slide-in-right">
              <div className="text-right">
                <p className="text-sm text-orange-600 dark:text-gray-200 oled:text-gray-200 font-mono">
                  {currentTime.toLocaleTimeString("id-ID")}
                </p>
                <p className="text-xs text-orange-500 dark:text-gray-300 oled:text-gray-300">
                  {currentTime.toLocaleDateString("id-ID")}
                </p>
              </div>
              <ThemeToggle />
              <AuthNav />
              <Button
                variant="outline"
                size="sm"
                onClick={() => window.open(settings.author.github, "_blank")}
                className="border-orange-300 dark:border-gray-600 oled:border-gray-800 text-orange-700 dark:text-gray-100 oled:text-gray-100 hover:bg-orange-50 dark:hover:bg-gray-800 oled:hover:bg-gray-900 hover-lift"
              >
                <Github className="h-4 w-4 mr-2" />
                {settings.author.name}
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Greeting Section */}
        <div className="mb-12 text-center slide-in-up">
          <div className="relative inline-block">
            <h2 className="text-5xl font-bold bg-gradient-to-r from-orange-600 via-orange-500 to-orange-700 dark:from-gray-100 dark:via-gray-200 dark:to-gray-300 oled:from-gray-200 oled:via-gray-300 oled:to-gray-400 bg-clip-text text-transparent mb-4 float-animation">
              {greeting}
            </h2>
            <Sparkles className="absolute -top-2 -right-8 h-8 w-8 text-orange-400 dark:text-gray-200 oled:text-gray-200 animate-pulse" />
          </div>
          <p className="text-lg text-orange-600 dark:text-gray-200 oled:text-gray-200 max-w-2xl mx-auto">
            Selamat datang di dashboard monitoring API Senko-san! 🦊
          </p>
        </div>

        {/* Notifications */}
        {notifications.length > 0 && (
          <div className="mb-8 space-y-4">
            {notifications.map((notification, index) => (
              <Alert
                key={notification.id}
                className={`border-l-4 glass dark:glass-dark oled:glass-oled hover-lift slide-in-up delay-${(index + 1) * 100} ${
                  notification.type === "error"
                    ? "border-red-500 bg-red-50/80 dark:bg-red-900/10 oled:bg-red-900/5"
                    : notification.type === "warning"
                      ? "border-yellow-500 bg-yellow-50/80 dark:bg-yellow-900/10 oled:bg-yellow-900/5"
                      : "border-orange-500 bg-orange-50/80 dark:bg-gray-800/30 oled:bg-gray-900/5"
                }`}
              >
                <AlertCircle className="h-4 w-4" />
                <AlertTitle className="dark:text-gray-100 oled:text-white">{notification.title}</AlertTitle>
                <AlertDescription className="dark:text-gray-200 oled:text-gray-200">
                  {notification.message}
                </AlertDescription>
              </Alert>
            ))}
          </div>
        )}

        {/* Server Stats */}
        {serverStats && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card className="glass dark:glass-dark oled:glass-oled border-orange-200/50 dark:border-gray-700/50 oled:border-gray-900/50 hover-lift slide-in-up delay-100">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-orange-700 dark:text-gray-100 oled:text-gray-100">
                  Uptime
                </CardTitle>
                <Clock className="h-5 w-5 text-orange-500 dark:text-gray-300 oled:text-gray-300 animate-pulse" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold bg-gradient-to-r from-orange-600 to-orange-800 dark:from-gray-100 dark:to-gray-300 oled:from-gray-200 oled:to-gray-400 bg-clip-text text-transparent">
                  {formatUptime(serverStats.uptime)}
                </div>
              </CardContent>
            </Card>

            <Card className="glass dark:glass-dark oled:glass-oled border-orange-200/50 dark:border-gray-700/50 oled:border-gray-900/50 hover-lift slide-in-up delay-200">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-orange-700 dark:text-gray-100 oled:text-gray-100">
                  Total Requests
                </CardTitle>
                <Zap className="h-5 w-5 text-orange-500 dark:text-gray-300 oled:text-gray-300 animate-bounce" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold bg-gradient-to-r from-orange-600 to-orange-800 dark:from-gray-100 dark:to-gray-300 oled:from-gray-200 oled:to-gray-400 bg-clip-text text-transparent">
                  <AnimatedCounter value={serverStats.totalRequests} />
                </div>
              </CardContent>
            </Card>

            <Card className="glass dark:glass-dark oled:glass-oled border-orange-200/50 dark:border-gray-700/50 oled:border-gray-900/50 hover-lift slide-in-up delay-300">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-orange-700 dark:text-gray-100 oled:text-gray-100">
                  Error Rate
                </CardTitle>
                <AlertCircle className="h-5 w-5 text-orange-500 dark:text-gray-300 oled:text-gray-300" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold bg-gradient-to-r from-orange-600 to-orange-800 dark:from-gray-100 dark:to-gray-300 oled:from-gray-200 oled:to-gray-400 bg-clip-text text-transparent">
                  <AnimatedCounter value={serverStats.errorRate} formatter={(val) => val.toFixed(2)} suffix="%" />
                </div>
              </CardContent>
            </Card>

            <Card className="glass dark:glass-dark oled:glass-oled border-orange-200/50 dark:border-gray-700/50 oled:border-gray-900/50 hover-lift slide-in-up delay-400">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-orange-700 dark:text-gray-100 oled:text-gray-100">
                  Avg Response
                </CardTitle>
                <Server className="h-5 w-5 text-orange-500 dark:text-gray-300 oled:text-gray-300" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold bg-gradient-to-r from-orange-600 to-orange-800 dark:from-gray-100 dark:to-gray-300 oled:from-gray-200 oled:to-gray-400 bg-clip-text text-transparent">
                  <AnimatedCounter value={serverStats.avgResponseTime} suffix="ms" />
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* API Status */}
        <Card className="glass dark:glass-dark oled:glass-oled border-orange-200/50 dark:border-gray-700/50 oled:border-gray-900/50 hover-lift slide-in-up">
          <CardHeader>
            <CardTitle className="text-xl bg-gradient-to-r from-orange-600 to-orange-800 dark:from-gray-100 dark:to-gray-300 oled:from-gray-200 oled:to-gray-400 bg-clip-text text-transparent">
              Status API
            </CardTitle>
            <CardDescription className="text-orange-600 dark:text-gray-200 oled:text-gray-200">
              Status API dari settings.json
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {apiStatuses.map((api, index) => (
                <div
                  key={api.id}
                  className={`flex items-center justify-between p-4 rounded-lg border border-orange-200/50 dark:border-gray-700/50 oled:border-gray-900/50 bg-gradient-to-r from-orange-50/50 to-orange-100/50 dark:from-gray-900/50 dark:to-gray-800/50 oled:from-black oled:to-gray-900/30 hover-lift slide-in-up delay-${
                    (index + 1) * 100
                  } transition-all duration-300`}
                >
                  <div className="flex items-center space-x-4">
                    <StatusIndicator status={api.status} />
                    <div>
                      <h3 className="font-semibold text-orange-800 dark:text-white oled:text-white">{api.name}</h3>
                      <p className="text-sm text-orange-600 dark:text-gray-200 oled:text-gray-200 font-mono">
                        {api.endpoint}
                      </p>
                      <p className="text-xs text-orange-500 dark:text-gray-300 oled:text-gray-300 mt-1">
                        {api.description}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="flex flex-wrap gap-1">
                      {api.methods.map((method) => (
                        <Badge
                          key={method}
                          variant="outline"
                          className={`text-xs ${
                            method === "GET"
                              ? "border-green-300 text-green-700 dark:border-green-600 dark:text-green-400"
                              : method === "POST"
                                ? "border-blue-300 text-blue-700 dark:border-blue-600 dark:text-blue-400"
                                : method === "PUT"
                                  ? "border-yellow-300 text-yellow-700 dark:border-yellow-600 dark:text-yellow-400"
                                  : "border-gray-300 text-gray-700 dark:border-gray-600 dark:text-gray-400"
                          }`}
                        >
                          {method}
                        </Badge>
                      ))}
                    </div>
                    <Badge
                      variant="outline"
                      className="border-orange-300 dark:border-gray-600 oled:border-gray-800 text-orange-700 dark:text-gray-100 oled:text-gray-100 bg-orange-50/50 dark:bg-gray-800/50 oled:bg-black/50"
                    >
                      {api.category}
                    </Badge>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleApiTest(api)}
                      disabled={api.status === "error" || api.status === "offline" || api.status === "maintenance"}
                      className={`border-orange-300 dark:border-gray-600 oled:border-gray-800 text-orange-700 dark:text-gray-100 oled:text-gray-100 hover:bg-orange-50 dark:hover:bg-gray-800 oled:hover:bg-gray-900 hover-lift ${
                        api.status === "error" || api.status === "offline" || api.status === "maintenance"
                          ? "opacity-50 cursor-not-allowed"
                          : ""
                      }`}
                    >
                      <TestTube className="h-4 w-4 mr-1" />
                      Test
                    </Button>
                    <div className="text-right">
                      <div className="flex items-center space-x-2">
                        <span className="text-sm font-medium text-orange-800 dark:text-white oled:text-white capitalize">
                          {api.status}
                        </span>
                      </div>
                      <p className="text-xs text-orange-600 dark:text-gray-200 oled:text-gray-200 font-mono">
                        <AnimatedCounter value={api.responseTime} suffix="ms" />
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <footer className="mt-16 text-center text-orange-600 dark:text-gray-200 oled:text-gray-200 slide-in-up">
          <div className="space-y-2">
            <p className="text-sm">
              Dibuat dengan ❤️ oleh{" "}
              <a
                href={settings.author.github}
                target="_blank"
                rel="noopener noreferrer"
                className="font-semibold hover:text-orange-800 dark:hover:text-white oled:hover:text-white transition-colors duration-300 bg-gradient-to-r from-orange-600 to-orange-800 dark:from-gray-100 dark:to-gray-300 oled:from-gray-200 oled:to-gray-400 bg-clip-text text-transparent"
              >
                {settings.author.name}
              </a>
            </p>
            <p className="text-xs mt-2 dark:text-gray-300 oled:text-gray-300">
              Tema Senko-san • Dashboard API Monitoring
            </p>
          </div>
        </footer>
      </main>

      {/* API Tester Modal */}
      {selectedApi && (
        <ApiTesterModal
          isOpen={isModalOpen}
          onClose={() => {
            setIsModalOpen(false)
            setSelectedApi(null)
          }}
          api={selectedApi}
        />
      )}
    </div>
  )
}
