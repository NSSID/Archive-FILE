import { NextRequest, NextResponse } from 'next/server';
import connectToDatabase from '@/lib/mongodb';
import User from '@/models/User';
import { generateToken } from '@/lib/jwt';

export async function POST(request: NextRequest) {
  try {
    console.log('Registration request received');
    
    // Connect to the database
    try {
      console.log('Connecting to MongoDB...');
      await connectToDatabase();
      console.log('MongoDB connection successful');
    } catch (dbError: any) {
      console.error('MongoDB connection error:', dbError);
      return NextResponse.json(
        {
          success: false,
          message: 'Database connection failed',
          error: dbError.message || 'Could not connect to database',
        },
        { status: 500 }
      );
    }

    // Get request body
    let body;
    try {
      body = await request.json();
      console.log('Request body parsed:', { ...body, password: '[REDACTED]' });
    } catch (parseError: any) {
      console.error('Request body parse error:', parseError);
      return NextResponse.json(
        {
          success: false,
          message: 'Invalid request body',
          error: 'Could not parse JSON body',
        },
        { status: 400 }
      );
    }
    
    const { username, email, password, displayName } = body;
    
    // Validate required fields
    if (!username || !email || !password) {
      return NextResponse.json(
        {
          success: false,
          message: 'Missing required fields',
          errors: [
            !username && 'Username is required',
            !email && 'Email is required',
            !password && 'Password is required',
          ].filter(Boolean),
        },
        { status: 400 }
      );
    }

    // Check if user already exists
    try {
      console.log('Checking if user exists...');
      const existingUser = await User.findOne({
        $or: [{ email }, { username }],
      });

      if (existingUser) {
        return NextResponse.json(
          {
            success: false,
            message: existingUser.email === email
              ? 'Email already in use'
              : 'Username already taken',
          },
          { status: 409 }
        );
      }
    } catch (queryError: any) {
      console.error('Error checking existing user:', queryError);
      return NextResponse.json(
        {
          success: false,
          message: 'Error checking user existence',
          error: queryError.message,
        },
        { status: 500 }
      );
    }

    // Create new user
    let user;
    try {
      console.log('Creating new user...');
      user = await User.create({
        username,
        email,
        password,
        displayName: displayName || username,
        avatar: `/placeholder-user.jpg`,
      });
      console.log('User created successfully:', user._id.toString());
    } catch (createError: any) {
      console.error('Error creating user:', createError);
      return NextResponse.json(
        {
          success: false,
          message: 'Failed to create user',
          error: createError.message || 'An error occurred while creating user',
        },
        { status: 500 }
      );
    }

    // Generate JWT token
    let token;
    try {
      token = generateToken(user);
    } catch (tokenError: any) {
      console.error('Error generating token:', tokenError);
      return NextResponse.json(
        {
          success: false,
          message: 'Failed to generate authentication token',
          error: tokenError.message,
        },
        { status: 500 }
      );
    }

    // Return success response
    return NextResponse.json({
      success: true,
      message: 'User registered successfully',
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        displayName: user.displayName,
        avatar: user.avatar,
        role: user.role,
      },
      token,
    });
  } catch (error: any) {
    console.error('Registration error:', error);
    
    // Handle validation errors
    if (error.name === 'ValidationError') {
      const validationErrors = Object.values(error.errors).map((err: any) => err.message);
      
      return NextResponse.json(
        {
          success: false,
          message: 'Validation failed',
          errors: validationErrors,
        },
        { status: 400 }
      );
    }
    
    // Handle other errors
    return NextResponse.json(
      {
        success: false,
        message: 'Registration failed',
        error: error.message || 'An error occurred during registration',
      },
      { status: 500 }
    );
  }
} 