import { NextRequest, NextResponse } from 'next/server';
import connectToDatabase from '@/lib/mongodb';
import User from '@/models/User';
import { generateToken } from '@/lib/jwt';

export async function POST(request: NextRequest) {
  try {
    // Connect to the database
    await connectToDatabase();

    // Get request body
    const body = await request.json();
    const { username, email, password } = body;

    if (!password || (!username && !email)) {
      return NextResponse.json(
        {
          success: false,
          message: 'Please provide username/email and password',
        },
        { status: 400 }
      );
    }

    // Find user by username or email and explicitly select password field
    const user = await User.findOne({
      $or: [
        { username: username || '' },
        { email: email || '' }
      ]
    }).select('+password');

    // Check if user exists
    if (!user) {
      return NextResponse.json(
        {
          success: false,
          message: 'Invalid credentials',
        },
        { status: 401 }
      );
    }

    // Check if password is correct
    const isPasswordValid = await user.comparePassword(password);
    if (!isPasswordValid) {
      return NextResponse.json(
        {
          success: false,
          message: 'Invalid credentials',
        },
        { status: 401 }
      );
    }

    // Generate JWT token
    const token = generateToken(user);

    // Return success response
    return NextResponse.json({
      success: true,
      message: 'Login successful',
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        displayName: user.displayName,
        avatar: user.avatar,
        role: user.role,
      },
      token,
    });
  } catch (error: any) {
    console.error('Login error:', error);
    
    return NextResponse.json(
      {
        success: false,
        message: 'Login failed',
        error: error.message || 'An error occurred during login',
      },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  // Validate API key
  const authResult = requireApiKey(request)
  if (!authResult.success) {
    return NextResponse.json(
      {
        status: false,
        message: "Authentication failed",
        error: authResult.error,
      },
      { status: 403 },
    )
  }

  return NextResponse.json({
    message: "Auth API is running",
    status: "online",
    timestamp: new Date().toISOString(),
    apiKey: {
      name: authResult.keyData?.name,
      usage: authResult.keyData?.usage,
    },
  })
}
