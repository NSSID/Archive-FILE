import { NextRequest, NextResponse } from 'next/server';
import connectToDatabase from '@/lib/mongodb';
import User from '@/models/User';
import { getUserFromToken } from '@/lib/jwt';

export async function GET(request: NextRequest) {
  try {
    // Get user from token
    const userPayload = getUserFromToken(request);
    
    if (!userPayload) {
      return NextResponse.json(
        {
          success: false,
          message: 'Unauthorized - Invalid or missing token',
        },
        { status: 401 }
      );
    }

    // Connect to the database
    await connectToDatabase();

    // Find user by ID
    const user = await User.findById(userPayload.id);

    if (!user) {
      return NextResponse.json(
        {
          success: false,
          message: 'User not found',
        },
        { status: 404 }
      );
    }

    // Return user data
    return NextResponse.json({
      success: true,
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        displayName: user.displayName,
        avatar: user.avatar,
        role: user.role,
        createdAt: user.createdAt,
      },
    });
  } catch (error: any) {
    console.error('Profile error:', error);
    
    return NextResponse.json(
      {
        success: false,
        message: 'Failed to fetch user profile',
        error: error.message || 'An error occurred',
      },
      { status: 500 }
    );
  }
} 