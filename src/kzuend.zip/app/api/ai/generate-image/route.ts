import { type NextRequest, NextResponse } from "next/server"
import { requireApiKey } from "@/lib/api-auth"

export async function POST(request: NextRequest) {
  // Validate API key
  const authResult = requireApiKey(request)
  if (!authResult.success) {
    return NextResponse.json(
      {
        status: false,
        message: "Authentication failed",
        error: authResult.error,
      },
      { status: 403 },
    )
  }

  try {
    const body = await request.json()
    const { prompt, style = "realistic", size = "512x512" } = body

    if (!prompt) {
      return NextResponse.json({ status: false, message: "Prompt is required" }, { status: 400 })
    }

    // Simulate AI image generation
    const imageUrl = `https://picsum.photos/512/512?random=${Date.now()}`

    return NextResponse.json({
      status: true,
      message: "Image generated successfully",
      data: {
        prompt,
        style,
        size,
        imageUrl,
        generationId: `gen_${Date.now()}`,
        timestamp: new Date().toISOString(),
      },
      apiKey: {
        name: authResult.keyData?.name,
        usage: authResult.keyData?.usage,
      },
    })
  } catch (error) {
    return NextResponse.json(
      {
        status: false,
        message: "Image generation failed",
        error: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
