import { type NextRequest, NextResponse } from "next/server"
import { requireApiKey } from "@/lib/api-auth"

// Option 1: Using wttr.in (No API key required)
// Free weather service that provides JSON data
const WTTR_BASE_URL = "https://wttr.in"

// Option 2: Using Open-Meteo (No API key required)
// Free weather API with good coverage
const OPEN_METEO_BASE_URL = "https://api.open-meteo.com/v1"

// Helper function to get coordinates from city name using OpenStreetMap Nominatim
async function getCityCoordinates(city: string) {
  try {
    const response = await fetch(
      `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(city)}&format=json&limit=1`,
    )
    const data = await response.json()

    if (data.length > 0) {
      return {
        lat: Number.parseFloat(data[0].lat),
        lon: Number.parseFloat(data[0].lon),
        display_name: data[0].display_name,
      }
    }
    return null
  } catch (error) {
    console.error("Error getting coordinates:", error)
    return null
  }
}

// Helper function to get weather from wttr.in
async function getWeatherFromWttr(city: string) {
  try {
    const response = await fetch(`${WTTR_BASE_URL}/${encodeURIComponent(city)}?format=j1`)

    if (!response.ok) {
      throw new Error(`wttr.in API error: ${response.status}`)
    }

    const data = await response.json()
    const current = data.current_condition[0]
    const location = data.nearest_area[0]

    return {
      city: location.areaName[0].value,
      country: location.country[0].value,
      temperature: Number.parseInt(current.temp_C),
      humidity: Number.parseInt(current.humidity),
      condition: current.weatherDesc[0].value.toLowerCase(),
      windSpeed: Math.round(Number.parseFloat(current.windspeedKmph)),
      pressure: Number.parseInt(current.pressure),
      units: "°C",
      source: "wttr.in",
    }
  } catch (error) {
    console.error("wttr.in error:", error)
    return null
  }
}

// Helper function to get weather from Open-Meteo
async function getWeatherFromOpenMeteo(city: string) {
  try {
    // First get coordinates
    const coords = await getCityCoordinates(city)
    if (!coords) {
      throw new Error("City not found")
    }

    // Then get weather data
    const response = await fetch(
      `${OPEN_METEO_BASE_URL}/forecast?latitude=${coords.lat}&longitude=${coords.lon}&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m,surface_pressure&timezone=auto`,
    )

    if (!response.ok) {
      throw new Error(`Open-Meteo API error: ${response.status}`)
    }

    const data = await response.json()
    const current = data.current

    // Convert weather code to description
    const getWeatherDescription = (code: number) => {
      const weatherCodes: { [key: number]: string } = {
        0: "clear sky",
        1: "mainly clear",
        2: "partly cloudy",
        3: "overcast",
        45: "fog",
        48: "depositing rime fog",
        51: "light drizzle",
        53: "moderate drizzle",
        55: "dense drizzle",
        61: "slight rain",
        63: "moderate rain",
        65: "heavy rain",
        71: "slight snow",
        73: "moderate snow",
        75: "heavy snow",
        80: "slight rain showers",
        81: "moderate rain showers",
        82: "violent rain showers",
        95: "thunderstorm",
        96: "thunderstorm with slight hail",
        99: "thunderstorm with heavy hail",
      }
      return weatherCodes[code] || "unknown"
    }

    return {
      city: coords.display_name.split(",")[0],
      country: coords.display_name.split(",").slice(-1)[0].trim(),
      temperature: Math.round(current.temperature_2m),
      humidity: Math.round(current.relative_humidity_2m),
      condition: getWeatherDescription(current.weather_code),
      windSpeed: Math.round(current.wind_speed_10m * 3.6), // Convert m/s to km/h
      pressure: Math.round(current.surface_pressure),
      units: "°C",
      source: "Open-Meteo",
    }
  } catch (error) {
    console.error("Open-Meteo error:", error)
    return null
  }
}

// Helper function to get forecast from Open-Meteo
async function getForecastFromOpenMeteo(city: string) {
  try {
    const coords = await getCityCoordinates(city)
    if (!coords) {
      throw new Error("City not found")
    }

    const response = await fetch(
      `${OPEN_METEO_BASE_URL}/forecast?latitude=${coords.lat}&longitude=${coords.lon}&daily=temperature_2m_max,weather_code&timezone=auto&forecast_days=5`,
    )

    if (!response.ok) {
      throw new Error(`Open-Meteo API error: ${response.status}`)
    }

    const data = await response.json()

    const getWeatherDescription = (code: number) => {
      const weatherCodes: { [key: number]: string } = {
        0: "clear sky",
        1: "mainly clear",
        2: "partly cloudy",
        3: "overcast",
        45: "fog",
        48: "depositing rime fog",
        51: "light drizzle",
        53: "moderate drizzle",
        55: "dense drizzle",
        61: "slight rain",
        63: "moderate rain",
        65: "heavy rain",
        71: "slight snow",
        73: "moderate snow",
        75: "heavy snow",
        80: "slight rain showers",
        81: "moderate rain showers",
        82: "violent rain showers",
        95: "thunderstorm",
        96: "thunderstorm with slight hail",
        99: "thunderstorm with heavy hail",
      }
      return weatherCodes[code] || "unknown"
    }

    const forecast = data.daily.time.map((date: string, index: number) => ({
      day: new Date(date).toLocaleDateString("en-US", {
        weekday: "long",
        month: "short",
        day: "numeric",
      }),
      temperature: Math.round(data.daily.temperature_2m_max[index]),
      condition: getWeatherDescription(data.daily.weather_code[index]),
    }))

    return forecast
  } catch (error) {
    console.error("Forecast error:", error)
    return []
  }
}

export async function GET(request: NextRequest) {
  // Validate API key
  const authResult = requireApiKey(request)
  if (!authResult.success) {
    return NextResponse.json(
      {
        status: false,
        message: "Authentication failed",
        error: authResult.error,
      },
      { status: 401 },
    )
  }

  try {
    const { searchParams } = new URL(request.url)
    const city = searchParams.get("city") || "Jakarta"

    // Try Open-Meteo first, fallback to wttr.in
    let weatherData = await getWeatherFromOpenMeteo(city)

    // Fallback to wttr.in if Open-Meteo fails
    if (!weatherData) {
      console.log(`Open-Meteo failed, trying wttr.in...`)
      weatherData = await getWeatherFromWttr(city)
    }

    if (!weatherData) {
      return NextResponse.json(
        {
          status: false,
          message: `Unable to get weather data for '${city}'`,
        },
        { status: 404 },
      )
    }

    return NextResponse.json({
      status: true,
      message: "Weather data retrieved successfully",
      data: weatherData,
      timestamp: new Date().toISOString(),
      apiKey: {
        name: authResult.keyData?.name,
        usage: authResult.keyData?.usage,
      },
    })
  } catch (error) {
    console.error("Weather API error:", error)
    return NextResponse.json(
      {
        status: false,
        message: "Failed to get weather data",
        error: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

export async function POST(request: NextRequest) {
  // Validate API key
  const authResult = requireApiKey(request)
  if (!authResult.success) {
    return NextResponse.json(
      {
        status: false,
        message: "Authentication failed",
        error: authResult.error,
      },
      { status: 401 },
    )
  }

  try {
    const body = await request.json()
    const { city } = body

    if (!city) {
      return NextResponse.json({ status: false, message: "City is required" }, { status: 400 })
    }

    // Get current weather - try Open-Meteo first
    let currentWeather = await getWeatherFromOpenMeteo(city)

    // Fallback to wttr.in if Open-Meteo fails
    if (!currentWeather) {
      currentWeather = await getWeatherFromWttr(city)
    }

    if (!currentWeather) {
      return NextResponse.json(
        {
          status: false,
          message: `Unable to get weather data for '${city}'`,
        },
        { status: 404 },
      )
    }

    // Get forecast (only available from Open-Meteo)
    const forecast = await getForecastFromOpenMeteo(city)

    const detailedWeatherData = {
      city: currentWeather.city,
      country: currentWeather.country,
      units: currentWeather.units,
      source: currentWeather.source,
      current: {
        temperature: currentWeather.temperature,
        humidity: currentWeather.humidity,
        condition: currentWeather.condition,
        windSpeed: currentWeather.windSpeed,
        pressure: currentWeather.pressure,
      },
      forecast: forecast,
    }

    return NextResponse.json({
      status: true,
      message: "Detailed weather data retrieved successfully",
      data: detailedWeatherData,
      timestamp: new Date().toISOString(),
      apiKey: {
        name: authResult.keyData?.name,
        usage: authResult.keyData?.usage,
      },
    })
  } catch (error) {
    console.error("Weather API error:", error)
    return NextResponse.json(
      {
        status: false,
        message: "Failed to get weather data",
        error: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
