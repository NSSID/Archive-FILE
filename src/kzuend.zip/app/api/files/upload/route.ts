import { type NextRequest, NextResponse } from "next/server"
import { requireApiKey } from "@/lib/api-auth"

export async function POST(request: NextRequest) {
  // Validate API key
  const authResult = requireApiKey(request)
  if (!authResult.success) {
    return NextResponse.json(
      {
        status: false,
        message: "Authentication failed",
        error: authResult.error,
      },
      { status: 403 },
    )
  }

  try {
    const formData = await request.formData()
    const file = formData.get("file") as File

    if (!file) {
      return NextResponse.json({ status: false, message: "No file uploaded" }, { status: 400 })
    }

    // Simulate file processing
    const fileInfo = {
      name: file.name,
      size: file.size,
      type: file.type,
      lastModified: file.lastModified,
    }

    return NextResponse.json({
      status: true,
      message: "File uploaded successfully",
      data: {
        ...fileInfo,
        uploadId: `upload_${Date.now()}`,
        url: `/uploads/${file.name}`,
        timestamp: new Date().toISOString(),
      },
      apiKey: {
        name: authResult.keyData?.name,
        usage: authResult.keyData?.usage,
      },
    })
  } catch (error) {
    return NextResponse.json(
      { status: false, message: "Upload failed", error: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 },
    )
  }
}
