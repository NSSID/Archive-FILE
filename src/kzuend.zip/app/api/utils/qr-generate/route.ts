import { type NextRequest, NextResponse } from "next/server"
import { requireApiKey } from "@/lib/api-auth"

export async function GET(request: NextRequest) {
  // Validate API key
  const authResult = requireApiKey(request)
  if (!authResult.success) {
    return NextResponse.json(
      {
        status: false,
        message: "Authentication failed",
        error: authResult.error,
      },
      { status: 403 },
    )
  }

  try {
    const { searchParams } = new URL(request.url)
    const text = searchParams.get("text") || "Hello World"
    const size = searchParams.get("size") || "200"

    // Simulate QR code generation (using QR Server API)
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encodeURIComponent(text)}`

    return NextResponse.json({
      status: true,
      message: "QR code generated successfully",
      data: {
        text,
        size: `${size}x${size}`,
        qrUrl,
        downloadUrl: qrUrl,
        timestamp: new Date().toISOString(),
      },
      apiKey: {
        name: authResult.keyData?.name,
        usage: authResult.keyData?.usage,
      },
    })
  } catch (error) {
    return NextResponse.json(
      {
        status: false,
        message: "QR generation failed",
        error: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

export async function POST(request: NextRequest) {
  // Validate API key
  const authResult = requireApiKey(request)
  if (!authResult.success) {
    return NextResponse.json(
      {
        status: false,
        message: "Authentication failed",
        error: authResult.error,
      },
      { status: 403 },
    )
  }

  try {
    const body = await request.json()
    const { text, size = 200, format = "png", errorCorrection = "M" } = body

    if (!text) {
      return NextResponse.json({ status: false, message: "Text is required" }, { status: 400 })
    }

    // Simulate advanced QR code generation
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encodeURIComponent(text)}&format=${format}&ecc=${errorCorrection}`

    return NextResponse.json({
      status: true,
      message: "Advanced QR code generated successfully",
      data: {
        text,
        size: `${size}x${size}`,
        format,
        errorCorrection,
        qrUrl,
        downloadUrl: qrUrl,
        timestamp: new Date().toISOString(),
      },
      apiKey: {
        name: authResult.keyData?.name,
        usage: authResult.keyData?.usage,
      },
    })
  } catch (error) {
    return NextResponse.json(
      {
        status: false,
        message: "QR generation failed",
        error: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
