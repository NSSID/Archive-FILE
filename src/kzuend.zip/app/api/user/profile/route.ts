import { type NextRequest, NextResponse } from "next/server"
import { requireApiKey } from "@/lib/api-auth"

export async function GET(request: NextRequest) {
  // Validate API key
  const authResult = requireApiKey(request)
  if (!authResult.success) {
    return NextResponse.json(
      {
        status: false,
        message: "Authentication failed",
        error: authResult.error,
      },
      { status: 403 },
    )
  }

  try {
    // Simulasi data profil user
    const userProfile = {
      id: 1,
      username: "senko",
      email: "senko@foxgirl.com",
      displayName: "Senko-san",
      avatar: "/placeholder.svg?height=100&width=100",
      role: "admin",
      joinDate: "2024-01-01",
      lastLogin: new Date().toISOString(),
      stats: {
        apiCalls: 1250,
        uptime: "99.9%",
        favoriteEndpoint: "/api/system/status",
      },
    }

    return NextResponse.json({
      success: true,
      data: userProfile,
      apiKey: {
        name: authResult.keyData?.name,
        usage: authResult.keyData?.usage,
      },
    })
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        message: "Error fetching profile",
      },
      { status: 500 },
    )
  }
}

export async function PUT(request: NextRequest) {
  // Validate API key
  const authResult = requireApiKey(request)
  if (!authResult.success) {
    return NextResponse.json(
      {
        status: false,
        message: "Authentication failed",
        error: authResult.error,
      },
      { status: 403 },
    )
  }

  try {
    const body = await request.json()

    // Simulasi update profil
    return NextResponse.json({
      success: true,
      message: "Profil berhasil diupdate",
      data: body,
      apiKey: {
        name: authResult.keyData?.name,
        usage: authResult.keyData?.usage,
      },
    })
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        message: "Error updating profile",
      },
      { status: 500 },
    )
  }
}
