import { type NextRequest, NextResponse } from "next/server"
import { requireApiKey } from "@/lib/api-auth"

const apiUrl = "https://api.waifu.pics/sfw/waifu"

export async function GET(request: NextRequest) {
  // Validate API key
  const authResult = requireApiKey(request)
  if (!authResult.success) {
    return NextResponse.json(
      {
        status: false,
        message: "Authentication failed",
        error: authResult.error,
      },
      { status: 403 },
    )
  }

  try {
    const response = await fetch(apiUrl, {
      method: "GET",
      headers: {
        "User-Agent": "Senko-API-Dashboard/1.0.0",
      },
    })

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }

    const data = await response.json()
    const imageUrl = data.url

    if (!imageUrl) {
      return NextResponse.json(
        {
          status: false,
          message: "URL gambar tidak ditemukan",
        },
        { status: 500 },
      )
    }

    return NextResponse.json({
      status: true,
      result: {
        url: imageUrl,
        extension: imageUrl.split(".").pop(),
        source: "waifu.pics",
        category: "sfw",
        type: "waifu",
        timestamp: new Date().toISOString(),
      },
      apiKey: {
        name: authResult.keyData?.name,
        usage: authResult.keyData?.usage,
      },
    })
  } catch (err) {
    console.error("Error fetching waifu image:", err)

    return NextResponse.json(
      {
        status: false,
        message: "Gagal mengambil gambar waifu",
        error: err instanceof Error ? err.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

export async function HEAD(request: NextRequest) {
  // Validate API key for HEAD requests too
  const authResult = requireApiKey(request)
  if (!authResult.success) {
    return new NextResponse(null, { status: 403 })
  }

  try {
    const response = await fetch(apiUrl, { method: "HEAD" })
    return new NextResponse(null, {
      status: response.ok ? 200 : 503,
      headers: {
        "X-API-Status": response.ok ? "healthy" : "unhealthy",
        "X-API-Key-Name": authResult.keyData?.name || "Unknown",
      },
    })
  } catch {
    return new NextResponse(null, { status: 503 })
  }
}
