import { type NextRequest, NextResponse } from "next/server"
import { requireApiKey } from "@/lib/api-auth"

// Server stats with persistent data across requests
let serverStats = {
  uptime: 0,
  totalRequests: 0,
  errorRate: 0,
  avgResponseTime: 0,
  startTime: Date.now(),
  lastUpdated: Date.now(),
}

// Reset server stats if server has been restarted (development mode)
const resetStatsIfNeeded = () => {
  const now = Date.now();
  // If more than 1 hour has passed since last update, reset stats
  // This helps in development mode when server restarts
  if (now - serverStats.lastUpdated > 3600000) {
    serverStats = {
      uptime: 0,
      totalRequests: 0,
      errorRate: 0,
      avgResponseTime: 0,
      startTime: now,
      lastUpdated: now,
    };
  } else {
    serverStats.lastUpdated = now;
  }
};

export async function GET(request: NextRequest) {
  try {
    // Validate API key
    const authResult = requireApiKey(request);
    if (!authResult.success) {
      return NextResponse.json(
        {
          status: false,
          message: "Authentication failed",
          error: authResult.error,
        },
        { status: 403 },
      );
    }

    // Reset stats if needed
    resetStatsIfNeeded();

    // Update uptime - ensure it's a valid number
    const uptimeSeconds = Math.floor((Date.now() - serverStats.startTime) / 1000);
    serverStats.uptime = uptimeSeconds > 0 ? uptimeSeconds : 0;

    // Increment request count
    serverStats.totalRequests += 1;
    
    // Generate realistic stats
    serverStats.errorRate = parseFloat((Math.min(Math.random() * 2, 2)).toFixed(2)); // 0-2% error rate
    serverStats.avgResponseTime = Math.floor(Math.random() * 100) + 50; // 50-150ms

    return NextResponse.json({
      status: true,
      data: {
        ...serverStats,
        apiKey: {
          name: authResult.keyData?.name || 'Unknown',
          usage: authResult.keyData?.usage || { totalRequests: 0 },
        },
      }
    });
  } catch (error) {
    console.error("Error in system stats API:", error);
    return NextResponse.json(
      {
        status: false,
        message: "Failed to fetch server stats",
        error: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    );
  }
}
