import { type NextRequest, NextResponse } from "next/server"
import { requireApiKey } from "@/lib/api-auth"

export async function GET(request: NextRequest) {
  // Validate API key
  const authResult = requireApiKey(request)
  if (!authResult.success) {
    return NextResponse.json(
      {
        status: false,
        message: "Authentication failed",
        error: authResult.error,
      },
      { status: 403 },
    )
  }

  try {
    const startTime = Date.now()

    // Simulasi health check
    const systemStatus = {
      status: "healthy",
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      memory: process.memoryUsage(),
      version: process.version,
      platform: process.platform,
      responseTime: Date.now() - startTime,
      services: {
        database: "online",
        cache: "online",
        storage: "online",
        external_api: "online",
      },
      apiKey: {
        name: authResult.keyData?.name,
        usage: authResult.keyData?.usage,
      },
    }

    return NextResponse.json(systemStatus)
  } catch (error) {
    return NextResponse.json(
      {
        status: "error",
        message: "System health check failed",
        timestamp: new Date().toISOString(),
      },
      { status: 500 },
    )
  }
}

export async function HEAD(request: NextRequest) {
  // Validate API key for HEAD requests too
  const authResult = requireApiKey(request)
  if (!authResult.success) {
    return new NextResponse(null, { status: 403 })
  }

  // Untuk ping check
  return new NextResponse(null, {
    status: 200,
    headers: {
      "X-API-Key-Name": authResult.keyData?.name || "Unknown",
    },
  })
}
