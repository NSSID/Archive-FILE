"use client"

import { CheckCircle, XCircle, AlertCircle, Wrench } from "lucide-react"
import { cn } from "@/lib/utils"

interface StatusIndicatorProps {
  status: "online" | "offline" | "error" | "maintenance"
  className?: string
  showPulse?: boolean
}

export function StatusIndicator({ status, className, showPulse = true }: StatusIndicatorProps) {
  const getStatusConfig = (status: string) => {
    switch (status) {
      case "online":
        return {
          icon: CheckCircle,
          color: "text-green-500",
          bgColor: "bg-green-500",
          pulseColor: "bg-green-400",
        }
      case "offline":
        return {
          icon: XCircle,
          color: "text-red-500",
          bgColor: "bg-red-500",
          pulseColor: "bg-red-400",
        }
      case "error":
        return {
          icon: AlertCircle,
          color: "text-yellow-500",
          bgColor: "bg-yellow-500",
          pulseColor: "bg-yellow-400",
        }
      case "maintenance":
        return {
          icon: Wrench,
          color: "text-blue-500",
          bgColor: "bg-blue-500",
          pulseColor: "bg-blue-400",
        }
      default:
        return {
          icon: AlertCircle,
          color: "text-gray-500",
          bgColor: "bg-gray-500",
          pulseColor: "bg-gray-400",
        }
    }
  }

  const config = getStatusConfig(status)
  const Icon = config.icon

  return (
    <div className={cn("flex items-center space-x-2", className)}>
      <div className="relative">
        <div className={cn("w-2 h-2 rounded-full", config.bgColor)}></div>
        {showPulse && (status === "online" || status === "maintenance") && (
          <div
            className={cn("absolute top-0 left-0 w-2 h-2 rounded-full animate-ping", config.pulseColor, "opacity-75")}
          ></div>
        )}
      </div>
      <Icon className={cn("h-4 w-4", config.color)} />
    </div>
  )
}
