"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  Play,
  Copy,
  Download,
  Loader2,
  CheckCircle,
  XCircle,
  Clock,
  Info,
  HelpCircle,
  Key,
  Shield,
  AlertTriangle,
} from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import Image from "next/image"

interface ApiTesterModalProps {
  isOpen: boolean
  onClose: () => void
  api: {
    id: string
    name: string
    endpoint: string
    methods: string[]
    responseType: string
    description: string
    category: string
    status?: "online" | "offline" | "error" | "maintenance"
    responseTime?: number
    lastChecked?: string
    parameters?: {
      hasParams: boolean
      description: string
      examples: Array<{
        name: string
        description: string
        type: string
        required: boolean
        default?: string
        example: string
      }>
    }
  }
}

interface TestResult {
  status: "success" | "error" | "loading" | "forbidden"
  statusCode?: number
  responseTime?: number
  data?: any
  error?: string
  headers?: Record<string, string>
}

// Fox Tail SVG Component
const FoxTailIcon = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="currentColor" className={className} xmlns="http://www.w3.org/2000/svg">
    <path d="M12 2C10.5 2 9.2 2.8 8.5 4C7.8 5.2 8 6.7 8.8 7.8C9.2 8.3 9.7 8.7 10.2 9C10.5 9.2 10.8 9.4 11 9.7C11.3 10.1 11.5 10.6 11.6 11.1C11.7 11.6 11.7 12.1 11.6 12.6C11.5 13.1 11.3 13.6 11 14C10.7 14.4 10.3 14.7 9.9 14.9C9.5 15.1 9 15.2 8.5 15.2C8 15.2 7.5 15.1 7.1 14.9C6.7 14.7 6.3 14.4 6 14C5.7 13.6 5.5 13.1 5.4 12.6C5.3 12.1 5.3 11.6 5.4 11.1C5.5 10.6 5.7 10.1 6 9.7C6.2 9.4 6.5 9.2 6.8 9C7.3 8.7 7.8 8.3 8.2 7.8C9 6.7 9.2 5.2 8.5 4C7.8 2.8 6.5 2 5 2C3.5 2 2.2 2.8 1.5 4C0.8 5.2 1 6.7 1.8 7.8C2.5 8.8 3.5 9.5 4.6 9.8C5.7 10.1 6.9 10 7.9 9.5C8.9 9 9.7 8.2 10.2 7.2C10.7 6.2 10.8 5 10.4 4C10 3 9.2 2.2 8.2 1.8C7.2 1.4 6 1.5 5 2Z" />
    <path d="M18 8C16.9 8 15.9 8.4 15.2 9.2C14.5 10 14.2 11.1 14.4 12.1C14.6 13.1 15.2 14 16 14.5C16.8 15 17.8 15.1 18.7 14.8C19.6 14.5 20.3 13.9 20.7 13.1C21.1 12.3 21.1 11.3 20.8 10.4C20.5 9.5 19.9 8.8 19.1 8.4C18.7 8.2 18.4 8.1 18 8Z" />
  </svg>
)

export function ApiTesterModal({ isOpen, onClose, api }: ApiTesterModalProps) {
  const [selectedMethod, setSelectedMethod] = useState(api.methods[0] || "GET")
  const [requestBody, setRequestBody] = useState("")
  const [headers, setHeaders] = useState('{"Content-Type": "application/json"}')
  const [queryParams, setQueryParams] = useState("")
  const [apiKey, setApiKey] = useState("senko_api_2024_demo_key_12345")
  const [testResult, setTestResult] = useState<TestResult | null>(null)
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const { toast } = useToast()

  const handleTest = async () => {
    if (!apiKey.trim()) {
      toast({
        title: "🔑 API Key Required",
        description: "Please provide an API key to test the endpoint.",
        variant: "destructive",
        duration: 3000,
      })
      return
    }

    // Show warning if API is not online
    if (api.status && api.status !== "online") {
      const statusMessages = {
        maintenance: "This API is under maintenance. Test results may not be accurate.",
        error: "This API is experiencing issues. Test may fail.",
        offline: "This API is currently offline. Test will likely fail."
      }
      
      toast({
        title: "⚠️ API Status Warning",
        description: statusMessages[api.status],
        duration: 5000,
      })
    }

    setTestResult({ status: "loading" })
    const startTime = Date.now()

    try {
      let url = api.endpoint
      const params = new URLSearchParams()

      // Always add API key
      params.append("apikey", apiKey)

      // Add other query parameters if provided
      if (queryParams) {
        queryParams.split("&").forEach((param) => {
          const [key, value] = param.split("=")
          if (key && value && key.trim() !== "apikey") {
            params.append(key.trim(), value.trim())
          }
        })
      }

      url += `?${params.toString()}`

      const requestOptions: RequestInit = {
        method: selectedMethod,
        headers: {
          ...JSON.parse(headers),
          "X-API-Key": apiKey, // Also send in header as backup
        },
      }

      if (selectedMethod !== "GET" && selectedMethod !== "HEAD") {
        if (selectedFile && api.id === "file-upload") {
          const formData = new FormData()
          formData.append("file", selectedFile)
          requestOptions.body = formData
          // Remove Content-Type header for FormData
          const parsedHeaders = JSON.parse(headers)
          delete parsedHeaders["Content-Type"]
          requestOptions.headers = {
            ...parsedHeaders,
            "X-API-Key": apiKey,
          }
        } else if (requestBody) {
          requestOptions.body = requestBody
        }
      }

      const response = await fetch(url, requestOptions)
      const responseTime = Date.now() - startTime

      let data
      const contentType = response.headers.get("content-type")

      if (contentType?.includes("application/json")) {
        data = await response.json()
      } else if (contentType?.includes("image/")) {
        data = { imageUrl: url, contentType }
      } else {
        data = await response.text()
      }

      const responseHeaders: Record<string, string> = {}
      response.headers.forEach((value, key) => {
        responseHeaders[key] = value
      })

      // Handle different status codes
      let status: TestResult["status"] = "success"
      if (response.status === 403) {
        status = "forbidden"
      } else if (!response.ok) {
        status = "error"
      }

      setTestResult({
        status,
        statusCode: response.status,
        responseTime,
        data,
        headers: responseHeaders,
        error: response.ok ? undefined : `HTTP ${response.status} ${response.statusText}`,
      })

      // Show specific toast for forbidden access
      if (response.status === 403) {
        toast({
          title: "🚫 Access Forbidden",
          description: "Invalid API key. Please check your API key and try again.",
          variant: "destructive",
          duration: 5000,
        })
      }
    } catch (error) {
      const responseTime = Date.now() - startTime
      setTestResult({
        status: "error",
        responseTime,
        error: error instanceof Error ? error.message : "Unknown error occurred",
      })

      toast({
        title: "❌ Request Failed",
        description: "Network error or server is unreachable.",
        variant: "destructive",
        duration: 3000,
      })
    }
  }

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text)
      toast({
        title: "📋 Copied to Clipboard!",
        description: "Response data has been copied to your clipboard successfully.",
        duration: 3000,
      })
    } catch (error) {
      toast({
        title: "❌ Copy Failed",
        description: "Failed to copy to clipboard. Please try again.",
        variant: "destructive",
        duration: 3000,
      })
    }
  }

  const downloadResponse = () => {
    if (!testResult?.data) return

    try {
      const dataStr = JSON.stringify(testResult.data, null, 2)
      const dataBlob = new Blob([dataStr], { type: "application/json" })
      const url = URL.createObjectURL(dataBlob)
      const link = document.createElement("a")
      link.href = url
      link.download = `${api.id}_response_${new Date().toISOString().slice(0, 19).replace(/:/g, "-")}.json`
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      URL.revokeObjectURL(url)

      toast({
        title: "💾 Download Started!",
        description: `Response data is being downloaded as ${api.id}_response.json`,
        duration: 3000,
      })
    } catch (error) {
      toast({
        title: "❌ Download Failed",
        description: "Failed to download response data. Please try again.",
        variant: "destructive",
        duration: 3000,
      })
    }
  }

  const fillExampleParams = () => {
    if (!api.parameters?.hasParams || !api.parameters.examples.length) return

    const exampleParams = api.parameters.examples
      .filter((param) => param.name !== "apikey") // Exclude apikey from auto-fill
      .map((param) => param.example)
      .join("&")
    setQueryParams(exampleParams)
  }

  const getStatusIcon = () => {
    switch (testResult?.status) {
      case "loading":
        return <Loader2 className="h-4 w-4 animate-spin text-blue-500" />
      case "success":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "forbidden":
        return <Shield className="h-4 w-4 text-red-500" />
      case "error":
        return <XCircle className="h-4 w-4 text-red-500" />
      default:
        return <Clock className="h-4 w-4 text-gray-500" />
    }
  }

  const renderResponse = () => {
    if (!testResult) return null

    if (testResult.status === "loading") {
      return (
        <div className="flex items-center justify-center p-8">
          <Loader2 className="h-8 w-8 animate-spin text-orange-500" />
          <span className="ml-2 text-orange-600 dark:text-orange-400">Testing API...</span>
        </div>
      )
    }

    if (testResult.status === "forbidden") {
      return (
        <div className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
          <div className="flex items-center mb-2">
            <Shield className="h-5 w-5 text-red-500 mr-2" />
            <span className="font-medium text-red-700 dark:text-red-300">Access Forbidden (403)</span>
          </div>
          <p className="text-red-600 dark:text-red-400 mb-2">
            {testResult.error || "Invalid API key or insufficient permissions"}
          </p>
          <div className="text-sm text-red-500 dark:text-red-400">
            <p>• Check if your API key is correct</p>
            <p>• Ensure your API key is active and not expired</p>
            <p>• Verify you have permission to access this endpoint</p>
          </div>
        </div>
      )
    }

    if (testResult.status === "error") {
      return (
        <div className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
          <div className="flex items-center mb-2">
            <XCircle className="h-5 w-5 text-red-500 mr-2" />
            <span className="font-medium text-red-700 dark:text-red-300">Error</span>
          </div>
          <p className="text-red-600 dark:text-red-400">{testResult.error}</p>
        </div>
      )
    }

    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            {getStatusIcon()}
            <Badge
              variant={
                testResult.status === "success"
                  ? "default"
                  : testResult.status === "forbidden"
                    ? "destructive"
                    : "destructive"
              }
            >
              {testResult.statusCode}
            </Badge>
            <span className="text-sm text-gray-600 dark:text-gray-400">{testResult.responseTime}ms</span>
          </div>
          <div className="flex space-x-2">
            <Button
              size="sm"
              variant="outline"
              onClick={() => copyToClipboard(JSON.stringify(testResult.data, null, 2))}
              className="hover:bg-green-50 hover:border-green-300 hover:text-green-700 dark:hover:bg-green-900/20 dark:hover:border-green-600 dark:hover:text-green-400 transition-all duration-200"
              disabled={!testResult.data}
            >
              <Copy className="h-4 w-4 mr-1" />
              Copy
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={downloadResponse}
              className="hover:bg-blue-50 hover:border-blue-300 hover:text-blue-700 dark:hover:bg-blue-900/20 dark:hover:border-blue-600 dark:hover:text-blue-400 transition-all duration-200 bg-transparent"
              disabled={!testResult.data}
            >
              <Download className="h-4 w-4 mr-1" />
              Download
            </Button>
          </div>
        </div>

        <Tabs defaultValue="response" className="w-full">
          <TabsList>
            <TabsTrigger value="response">Response</TabsTrigger>
            <TabsTrigger value="headers">Headers</TabsTrigger>
          </TabsList>

          <TabsContent value="response" className="mt-4">
            {api.responseType === "image" && testResult.data?.imageUrl ? (
              <div className="space-y-4">
                <div className="relative aspect-square max-w-md mx-auto bg-gray-100 dark:bg-gray-800 rounded-lg overflow-hidden">
                  <Image
                    src={testResult.data.imageUrl || "/placeholder.svg"}
                    alt="API Response"
                    fill
                    className="object-cover transition-transform duration-300 hover:scale-105"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement
                      target.src = "/placeholder.svg?height=400&width=400"
                    }}
                  />
                </div>
                <ScrollArea className="h-40 w-full border rounded-lg p-4">
                  <pre className="text-sm whitespace-pre-wrap break-words">
                    {JSON.stringify(testResult.data, null, 2)}
                  </pre>
                </ScrollArea>
              </div>
            ) : (
              <ScrollArea className="h-80 w-full border rounded-lg p-4">
                <pre className="text-sm whitespace-pre-wrap break-words">
                  {testResult.data ? JSON.stringify(testResult.data, null, 2) : "No response data"}
                </pre>
              </ScrollArea>
            )}
          </TabsContent>

          <TabsContent value="headers" className="mt-4">
            <div className="flex justify-end mb-2">
              <Button
                size="sm"
                variant="outline"
                onClick={() => copyToClipboard(JSON.stringify(testResult.headers, null, 2))}
                className="hover:bg-green-50 hover:border-green-300 hover:text-green-700 dark:hover:bg-green-900/20 dark:hover:border-green-600 dark:hover:text-green-400 transition-all duration-200"
                disabled={!testResult.headers}
              >
                <Copy className="h-4 w-4 mr-1" />
                Copy Headers
              </Button>
            </div>
            <ScrollArea className="h-60 w-full border rounded-lg p-4">
              <pre className="text-sm whitespace-pre-wrap break-words">
                {testResult.headers ? JSON.stringify(testResult.headers, null, 2) : "No headers data"}
              </pre>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </div>
    )
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-3xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="text-xl flex items-center space-x-2">
            <span>Test API: {api.name}</span>
            <Badge variant="outline" className="ml-2">
              {api.category}
            </Badge>
          </DialogTitle>
          <DialogDescription className="text-sm">
            {api.description}
          </DialogDescription>
        </DialogHeader>

        {api.status && api.status !== "online" && (
          <Alert className={`mb-4 ${
            api.status === "maintenance" ? "bg-blue-50 border-blue-200 dark:border-blue-800 dark:bg-blue-950/20" :
            api.status === "error" ? "bg-yellow-50 border-yellow-200 dark:border-yellow-800 dark:bg-yellow-950/20" :
            "bg-red-50 border-red-200 dark:border-red-800 dark:bg-red-950/20"
          }`}>
            <AlertTriangle className={`h-4 w-4 ${
              api.status === "maintenance" ? "text-blue-500" :
              api.status === "error" ? "text-yellow-500" :
              "text-red-500"
            }`} />
            <AlertDescription className="text-sm">
              {api.status === "maintenance" 
                ? "This API is currently under maintenance. Testing may not work correctly."
                : api.status === "error" 
                ? "This API is currently experiencing errors. Testing may fail."
                : "This API is currently offline. Testing will likely fail."}
            </AlertDescription>
          </Alert>
        )}

        <ScrollArea className="max-h-[calc(95vh-120px)]">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 p-1">
            {/* Request Panel */}
            <div className="space-y-4">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg">Request Configuration</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex space-x-2">
                    <div className="flex-1">
                      <Label htmlFor="method">Method</Label>
                      <Select value={selectedMethod} onValueChange={setSelectedMethod}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {api.methods.map((method) => (
                            <SelectItem key={method} value={method}>
                              <Badge
                                variant={method === "GET" ? "default" : method === "POST" ? "destructive" : "secondary"}
                              >
                                {method}
                              </Badge>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="flex-2">
                      <Label htmlFor="endpoint">Endpoint</Label>
                      <Input value={api.endpoint} disabled />
                    </div>
                  </div>

                  {/* API Key Section */}
                  <div>
                    <div className="flex items-center space-x-2 mb-2">
                      <Label htmlFor="apikey">API Key</Label>
                      <Key className="h-4 w-4 text-orange-500" />
                      <Badge variant="destructive" className="text-xs">
                        Required
                      </Badge>
                    </div>
                    <Input
                      id="apikey"
                      type="password"
                      placeholder="Enter your API key"
                      value={apiKey}
                      onChange={(e) => setApiKey(e.target.value)}
                      className="font-mono"
                    />
                    <div className="mt-2 space-y-1">
                      <p className="text-xs text-gray-500">Demo key: senko_api_2024_demo_key_12345</p>
                      <Alert className="border-yellow-200 bg-yellow-50/50 dark:border-yellow-800 dark:bg-yellow-900/20">
                        <AlertTriangle className="h-4 w-4 text-yellow-600" />
                        <AlertDescription className="text-yellow-700 dark:text-yellow-300 text-xs">
                          <strong>Security Notice:</strong> Invalid API keys will result in 403 Forbidden errors. Make
                          sure your API key is active and has proper permissions.
                        </AlertDescription>
                      </Alert>
                    </div>
                  </div>

                  {/* Parameters Section */}
                  <div>
                    <div className="flex items-center space-x-2 mb-2">
                      <Label htmlFor="params">Additional Parameters</Label>
                      <HelpCircle className="h-4 w-4 text-gray-400" />
                    </div>

                    <Alert className="border-blue-200 bg-blue-50/50 dark:border-blue-800 dark:bg-blue-900/20 mb-3">
                      <Info className="h-4 w-4 text-blue-600" />
                      <AlertDescription className="text-blue-700 dark:text-blue-300">
                        <ScrollArea className="max-h-48">
                          <div className="space-y-2 pr-3">
                            <p className="font-medium">Authentication Required:</p>
                            <p className="text-sm">{api.parameters?.description}</p>
                            {api.parameters?.examples && api.parameters.examples.length > 1 && (
                              <div className="space-y-1">
                                <p className="text-sm font-medium">Additional Parameters:</p>
                                {api.parameters.examples
                                  .filter((param) => param.name !== "apikey")
                                  .map((param, index) => (
                                    <div key={index} className="text-xs bg-blue-100 dark:bg-blue-900/30 p-2 rounded">
                                      <div className="flex items-center space-x-2 flex-wrap">
                                        <Badge variant="outline" className="text-xs">
                                          {param.name}
                                        </Badge>
                                        <span className="text-gray-600 dark:text-gray-300">({param.type})</span>
                                        {param.required && (
                                          <Badge variant="destructive" className="text-xs">
                                            Required
                                          </Badge>
                                        )}
                                      </div>
                                      <p className="mt-1 text-gray-700 dark:text-gray-300 break-words">
                                        {param.description}
                                      </p>
                                      <p className="mt-1 font-mono text-green-700 dark:text-green-300 break-all">
                                        Example: {param.example}
                                      </p>
                                      {param.default && (
                                        <p className="text-gray-600 dark:text-gray-400 break-words">
                                          Default: {param.default}
                                        </p>
                                      )}
                                    </div>
                                  ))}
                              </div>
                            )}
                          </div>
                        </ScrollArea>
                      </AlertDescription>
                    </Alert>

                    <div className="flex space-x-2">
                      <Input
                        id="params"
                        placeholder="key1=value1&key2=value2 (API key will be added automatically)"
                        value={queryParams}
                        onChange={(e) => setQueryParams(e.target.value)}
                        className="flex-1"
                      />
                      {api.parameters?.examples &&
                        api.parameters.examples.filter((p) => p.name !== "apikey").length > 0 && (
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={fillExampleParams}
                            className="whitespace-nowrap bg-transparent"
                          >
                            Fill Example
                          </Button>
                        )}
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="headers">Headers (JSON)</Label>
                    <Textarea
                      id="headers"
                      rows={3}
                      value={headers}
                      onChange={(e) => setHeaders(e.target.value)}
                      className="font-mono text-sm"
                    />
                  </div>

                  {selectedMethod !== "GET" && selectedMethod !== "HEAD" && (
                    <div>
                      {api.id === "file-upload" ? (
                        <div>
                          <Label htmlFor="file">File Upload</Label>
                          <Input
                            id="file"
                            type="file"
                            onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
                            className="mt-1"
                          />
                          {selectedFile && (
                            <p className="text-sm text-gray-600 mt-1 break-words">
                              Selected: {selectedFile.name} ({(selectedFile.size / 1024).toFixed(2)} KB)
                            </p>
                          )}
                        </div>
                      ) : (
                        <div>
                          <Label htmlFor="body">Request Body (JSON)</Label>
                          <Textarea
                            id="body"
                            rows={6}
                            placeholder={getBodyPlaceholder()}
                            value={requestBody}
                            onChange={(e) => setRequestBody(e.target.value)}
                            className="font-mono text-sm"
                          />
                        </div>
                      )}
                    </div>
                  )}

                  <Button
                    onClick={handleTest}
                    className="w-full"
                    disabled={
                      testResult?.status === "loading" || 
                      !apiKey.trim() || 
                      (api.status && api.status !== "online")
                    }
                  >
                    {testResult?.status === "loading" ? (
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    ) : (
                      <Play className="h-4 w-4 mr-2" />
                    )}
                    {api.status && api.status !== "online" 
                      ? `API ${api.status === "maintenance" ? "Under Maintenance" : api.status === "error" ? "Has Errors" : "Offline"}`
                      : "Test API"
                    }
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* Response Panel */}
            <div>
              <Card className="h-full">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center">
                    Response
                    {testResult && <div className="ml-2 flex items-center space-x-1">{getStatusIcon()}</div>}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="min-h-[400px]">{renderResponse()}</div>
                </CardContent>
              </Card>
            </div>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  )

  function getBodyPlaceholder() {
    switch (api.id) {
      case "auth-login":
        return '{\n  "username": "senko",\n  "password": "foxgirl"\n}'
      case "user-profile":
        return '{\n  "displayName": "Senko-san",\n  "email": "senko@foxgirl.com"\n}'
      case "image-generator":
        return '{\n  "prompt": "A cute anime fox girl",\n  "style": "anime",\n  "size": "512x512"\n}'
      case "text-analyzer":
        return '{\n  "text": "This is a sample text to analyze",\n  "language": "en"\n}'
      case "weather":
        return '{\n  "city": "Jakarta",\n  "units": "metric"\n}'
      case "qr-generator":
        return '{\n  "text": "Hello World",\n  "size": 200,\n  "format": "png"\n}'
      default:
        return '{\n  "key": "value"\n}'
    }
  }
}
