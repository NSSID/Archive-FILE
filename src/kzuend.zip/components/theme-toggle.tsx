"use client"

import * as React from "react"
import { Moon, Sun, Smartphone } from "lucide-react"
import { useTheme } from "next-themes"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

export function ThemeToggle() {
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = React.useState(false)

  React.useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return (
      <Button variant="outline" size="icon" className="animate-pulse bg-transparent">
        <div className="h-4 w-4 bg-gray-300 rounded"></div>
      </Button>
    )
  }

  const getThemeIcon = () => {
    switch (theme) {
      case "light":
        return <Sun className="h-4 w-4 text-orange-600" />
      case "dark":
        return <Moon className="h-4 w-4 text-gray-400" />
      case "oled":
        return <Smartphone className="h-4 w-4 text-gray-300" />
      default:
        return <Sun className="h-4 w-4 text-orange-600" />
    }
  }

  const getThemeLabel = () => {
    switch (theme) {
      case "light":
        return "Light Mode"
      case "dark":
        return "Dark Mode"
      case "oled":
        return "OLED Black"
      default:
        return "Theme"
    }
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="outline"
          size="icon"
          className="relative overflow-hidden border-orange-300 dark:border-gray-600 oled:border-gray-800 hover:border-orange-400 transition-all duration-300 hover:scale-105 hover:shadow-lg bg-transparent"
          title={getThemeLabel()}
        >
          <div className="transition-transform duration-300 hover:rotate-12">{getThemeIcon()}</div>
          <span className="sr-only">Toggle theme</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent
        align="end"
        className="glass dark:glass-dark oled:glass-oled border-orange-200 dark:border-gray-700 oled:border-gray-900 min-w-[140px]"
      >
        <DropdownMenuItem
          onClick={() => setTheme("light")}
          className={`cursor-pointer hover:bg-orange-50 dark:hover:bg-gray-800 oled:hover:bg-gray-900 transition-colors duration-200 ${
            theme === "light" ? "bg-orange-100 dark:bg-gray-700 oled:bg-gray-800" : ""
          }`}
        >
          <Sun className="mr-2 h-4 w-4 text-orange-600" />
          <span className="text-orange-700 dark:text-gray-200 oled:text-gray-100">Light</span>
          {theme === "light" && <div className="ml-auto w-2 h-2 bg-orange-500 rounded-full"></div>}
        </DropdownMenuItem>
        <DropdownMenuItem
          onClick={() => setTheme("dark")}
          className={`cursor-pointer hover:bg-orange-50 dark:hover:bg-gray-800 oled:hover:bg-gray-900 transition-colors duration-200 ${
            theme === "dark" ? "bg-orange-100 dark:bg-gray-700 oled:bg-gray-800" : ""
          }`}
        >
          <Moon className="mr-2 h-4 w-4 text-gray-500" />
          <span className="text-orange-700 dark:text-gray-200 oled:text-gray-100">Dark</span>
          {theme === "dark" && <div className="ml-auto w-2 h-2 bg-gray-500 rounded-full"></div>}
        </DropdownMenuItem>
        <DropdownMenuItem
          onClick={() => setTheme("oled")}
          className={`cursor-pointer hover:bg-orange-50 dark:hover:bg-gray-800 oled:hover:bg-gray-900 transition-colors duration-200 ${
            theme === "oled" ? "bg-orange-100 dark:bg-gray-700 oled:bg-gray-800" : ""
          }`}
        >
          <Smartphone className="mr-2 h-4 w-4 text-gray-400" />
          <span className="text-orange-700 dark:text-gray-200 oled:text-gray-100">OLED Black</span>
          {theme === "oled" && <div className="ml-auto w-2 h-2 bg-gray-500 rounded-full"></div>}
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
